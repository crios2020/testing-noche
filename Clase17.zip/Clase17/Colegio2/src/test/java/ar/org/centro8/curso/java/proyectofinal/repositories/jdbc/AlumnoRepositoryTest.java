package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Alumno;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_AlumnoRepository;

public class AlumnoRepositoryTest {
   
    I_AlumnoRepository alumnoRepository=new AlumnoRepository(Connector.getConnection());

    @Test
    void testSave() {
        Alumno alumno1=new Alumno("xxx","xxx",20,1);
        Alumno alumno2=new Alumno("xxx","xxx",20,1);
        alumnoRepository.save(alumno1);
        alumnoRepository.save(alumno2);

        assertEquals(alumno1.getId()>0, true);
        assertEquals(alumno1.getId(), alumno2.getId()-1);
    }

    @Test
    void testGetAll() {
        assertEquals(alumnoRepository.getAll().size()>=2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial=alumnoRepository.getAll().size();
        alumnoRepository.remove(alumnoRepository.getAll().get(cantidadInicial-1));
        int cantidadFinal=alumnoRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal+1);
    }

    @Test
    void testUpdate() {
        int cantidad=alumnoRepository.getAll().size();
        Alumno alumno=alumnoRepository.getAll().get(cantidad-1);
        alumno.setNombre("ooo");
        alumno.setApellido("ooo");
        alumno.setEdad(20);;
        alumno.setIdCurso(2);
        alumnoRepository.update(alumno);
        Alumno alumno2=alumnoRepository.getAll().get(cantidad-1);

        assertEquals(alumno.getNombre(), alumno2.getNombre());
        assertEquals(alumno.getApellido(), alumno2.getApellido());
        assertEquals(alumno.getEdad(), alumno2.getEdad());
        assertEquals(alumno.getIdCurso(), alumno2.getIdCurso());

    }
}
