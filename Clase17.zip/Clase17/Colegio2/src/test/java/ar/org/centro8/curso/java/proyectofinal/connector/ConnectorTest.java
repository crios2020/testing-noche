package ar.org.centro8.curso.java.proyectofinal.connector;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.sql.Connection;
import java.sql.ResultSet;

import org.junit.jupiter.api.Test;

public class ConnectorTest {
    private Connection conn=Connector.getConnection();
    @Test
    void testGetConnection1() {
        assertNotEquals(conn,null);
    }

    @Test
    void testGetConnection2(){
        try{
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            assertEquals(rs.next(), true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    @Test
    void testGetConnection3(){
        try{
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            rs.next();
            assertEquals(rs.getString(1).length()>3, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    

}
