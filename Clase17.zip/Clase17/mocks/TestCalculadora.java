public class TestCalculadora {
    public static void main(String[] args) {
        //Realizamos Mocks de Calculadora

        Calculadora calculadora=new Calculadora();
        System.out.println(calculadora.sumar(2,3));         // 5
        System.out.println(calculadora.sumar(2,0));         // 2
        System.out.println(calculadora.restar(2,3));        //-1
        System.out.println(calculadora.dividir(20,5));      // 4
        System.out.println(calculadora.multiplicar(2,3));   // 6


    }
}
