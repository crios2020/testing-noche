public class TestCuenta {
    public static void main(String[] args) {
        //Mock Cuenta
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta();
        cuenta1.nro=1;
        cuenta1.moneda="arg$";
        cuenta1.depositar(60000);
        System.out.println(cuenta1);        //60000
        cuenta1.depositar(40000);   
        System.out.println(cuenta1);        //100000
        cuenta1.debitar(80000);         
        System.out.println(cuenta1);        //20000
        cuenta1.debitar(40000);      //error
        System.out.println(cuenta1);        //20000


    }
}
