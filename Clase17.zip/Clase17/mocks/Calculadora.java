public class Calculadora{
    public int sumar(int nro1, int nro2){
        return nro1+nro2;
    }
    public int restar(int nro1, int nro2){
        return nro1-nro2;
    }
    public int dividir(int nro1, int nro2){
        return nro1/nro2;
    }
    public int multiplicar(int nro1, int nro2){
        return nro1*nro2;
    }
}