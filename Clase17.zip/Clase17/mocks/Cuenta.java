public class Cuenta {
    int nro;
    String moneda;
    double saldo;

    void depositar(float monto){
        saldo=saldo+monto;
    }

    void debitar(float monto){
        if(monto<=saldo){
            saldo=saldo-monto;
        }else{
            System.out.println("No hay fondos suficientes!");
        }
    }

    @Override
    public String toString() {
        return "Cuenta [nro=" + nro + ", moneda=" + moneda + ", saldo=" + saldo + "]";
    }

    
}
