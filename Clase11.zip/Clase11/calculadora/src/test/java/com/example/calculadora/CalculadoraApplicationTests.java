package com.example.calculadora;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraApplicationTests {


	@Test
	public void sumar01(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(2,2), 4);
	}

	@Test
	public void sumar02(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(2,0), 2);
	}

	@Test
	public void sumar03(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(0,2), 2);
	}

	@Test
	public void sumar04(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(-10,-10), -20);
	}

}
