package com.example.calculadora;

/**
 * Clase principal del programa Calculadora.<br>
 * Requerimiento: Java 17 o sup.
 */
public class Calculadora{

    /**
     * Punto de entrada del proyecto
     * @param args argumentos que ingresan de consola.
     */
    public static void main(String[] args) {
        if(args.length==3){
            //TODO realizar operación
        }else{
            System.out.println("Ingrese 'nro1' 'operación' 'nro2'");
            System.out.println("Operación + - / x");
            System.out.println("Ejemplo: java Calculadora.java 12 + 24 ");
        }

        // Linea de comentarios

        /*
         * Bloque de comentarios
         */

        //TODO Tarea pendiente!!!


        /**
         * Comentario JAVA DOC
         * Tiene la posibilidad de ser visto desde fuera del Binario.
         * (Comentario que puede ver el usuario final) 
         */

    }

    /**
     * método que suma dos números
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public double sumar(double nro1, double nro2){
        //realizar y retornar suma de parámetros
        return nro1+nro2;
    }

    /**
     * método que resta dos números
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public double restar(double nro1, double nro2){
        //TODO realizar y retornar resta de parámetros
        return 0;
    }

    /**
     * método que multiplica dos números
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public double multiplicar(double nro1, double nro2){
        //TODO realizar y retornar multiplicación de parámetros
        return 0;
    }

    /**
     * método que divide dos números
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public double dividir(double nro1, double nro2){
        //TODO realizar y retornar división de parámetros
        return 0;
    }
}