public class Sumar{
    public static void main(String[] args) {
        if(args.length<2){
            System.out.println("Ingrese dos números!");
        }else{
            double nro1=Double.parseDouble(args[0]);
            double nro2=Double.parseDouble(args[1]);
            System.out.println(nro1+nro2);
        }
    }
}
