package com.example.calculadora;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CalculadoraTests {

    /**
     * Probamos suma de enteros 
     */
    @Test
    void testSumar1() {
        Calculadora calculadora=new Calculadora();
        assertEquals(calculadora.sumar(2, 2),4);
    }

    /**
     * Probamos el elemento neutro
     */
    @Test
    void testSumar2() {
        Calculadora calculadora=new Calculadora();
        assertEquals(calculadora.sumar(2, 0),2);
    }

    /**
     * Probamos el elemento neutro
     */
    @Test
    void testSumar3() {
        Calculadora calculadora=new Calculadora();
        assertEquals(calculadora.sumar(0, 2),2);
    }

    /**
     * Probamos suma de números no entero
     */
    @Test
    void testSumar4() {
        Calculadora calculadora=new Calculadora();
        assertEquals(calculadora.sumar(5.5, 4),9.5);
    }

    /**
     * Probamos desbordamiento
     */
    @Test
    void testSumar5() {
        Calculadora calculadora=new Calculadora();
        assertEquals(calculadora.sumar(2000000000, 2000000000),4000000000l);
    }

}
