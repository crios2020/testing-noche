-- comentario de una sola linea
/* bloque de comentarios */
-- drop database if exists colegio;
-- create database colegio;
-- use colegio;
drop table if exists alumnos;
drop table if exists cursos;
create table cursos(
    id int auto_increment primary key,
    titulo varchar(25) not null,
    profesor varchar(25) not null,
    -- dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
    dia varchar(25),
    -- turno enum('MAÑANA','TARDE','NOCHE')
    turno varchar(25)
);
create table alumnos(
    id int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    -- edad >=18 y <=120
    edad int,
    idCurso int not null
);

-- validar edad
-- alter table alumnos
--    add constraint CK_alumnos_edad
--    check(edad>=18 and edad<=120);

-- Restricción de clave foranea idCursos
-- alter table alumnos
--    add constraint FK_alumnos_idCurso
--    foreign key(idCurso)
--    references cursos(id);

/*
        DBA Data Base Administrator
*/
show tables;
-- insert into alumnos (nombre,apellido,edad,idCurso) values ('<h1>CArlos</h1>','<h1>Rios</h1>',25,1);
-- insert into alumnos (nombre,apellido,edad,idCurso) values ('<script>alert("you are','hacked")</script>',25,1);
-- insert into alumnos (nombre,apellido,edad,idCurso) values ('<font size=50>Carlos','Rios',25,1);
-- delete from alumnos where nombre like '%<%';
set sql_safe_updates=0;