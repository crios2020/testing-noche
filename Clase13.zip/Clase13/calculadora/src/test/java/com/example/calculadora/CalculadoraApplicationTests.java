package com.example.calculadora;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraApplicationTests {

	/**
	 * Test de Ejemplo 1
	 */
	@Test
	public void testInicial1(){
		assertEquals(2+2, 4);		//prueba correcta
	}

	/**
	 * Test de Ejemplo 2
	 */
	@Test
	public void testInicial2(){
		//assertEquals(2+3, 4);		//prueba erronea
	}

	/**
	 * Estamos sumando dos parámetros, se espera la suma de los parámetros enteros
	 */
	@Test
	public void testSumarDosParametros1(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.sumar(2,2),4);
	}

	@Test
	public void testSumarDosParametros2(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.sumar(10,5),14);	//prueba mal realizada
	}

	@Test
	public void testSumarDosParametros3(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.sumar(150,55),205);
	}
	
	@Test
	public void testSumarParametrosTipoIncorrecto(){
		//Calculadora calculadora=new Calculadora(); //objeto calculadora
		//NO SE PUEDE REALIZAR LA PRUEBA
		//assertEquals(calculadora.sumar(2 2,"2"),205);
		//assertEquals(calculadora.sumar("Hola","Chau"),205);
	}

	@Test
	public void testSumarNumerosNoEnteros(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.sumar(2.5,5.5),8);
	}

	@Test
	public void testSumarDesbordamiento(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.sumar(2000000000,2000000000),4000000000d);
	}

	@Test
	public void testSumarNegativos(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.sumar(20,-40),-20);
	}

	@Test
	public void testElementoNeutro(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.sumar(20,0),20);
	}

	@Test
	public void testDividirEnteros(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.dividir(20,2),10);
	}

	@Test
	public void testDividirEnteros2(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		assertEquals(calculadora.dividir(7,2),3.5);
	}

	@Test
	public void testDividirEnteros3(){
		Calculadora calculadora=new Calculadora(); //objeto calculadora
		try {
			calculadora.dividir(10,0);
			assertEquals(true,true);
		} catch (Exception e) {
			assertEquals(false, true);
		}
	}

	@Test
	public void testMultiplicacionDesbordamiento(){
		Calculadora calculadora=new Calculadora(); 
		try {
			calculadora.multiplicar(2000000000,2000000000);
			assertEquals(true,true);
		} catch (Exception e) {
			assertEquals(false, true);
		}
	}

	/**
	 * Test del método main
	 */
	@Test
	public void testMain1(){
		try{
			Calculadora.main("2","+","2");
			assertEquals(true, true);
			//Funciona todo OK
		}catch(Exception e){
			//Ocurrio un error!!!!
			assertEquals(false, true);
		}
		
	}

	@Test
	public void testMain2(){
		try{
			Calculadora.main("hola","+","chau");
			assertEquals(true, true);
			//Funciona todo OK
		}catch(Exception e){
			//Ocurrio un error!!!!
			assertEquals(false, true);
		}
		
	}

}
