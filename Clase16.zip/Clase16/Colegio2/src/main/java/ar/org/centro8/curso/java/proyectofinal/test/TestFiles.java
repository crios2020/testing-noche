package ar.org.centro8.curso.java.proyectofinal.test;

import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.utils.files.FileText;
import ar.org.centro8.curso.java.proyectofinal.utils.files.I_File;

public class TestFiles {
    public static void main(String[] args) {
        String file="texto.txt";
        I_File fText=new FileText(file);
        fText.setText("Curso de JAVA!!!\n");
        fText.appendText("Hoy es Miércoles!!!\n");
        fText.addLines(List.of("Lunes","Martes","Miércoles","Jueves","Viernes"));
        fText.getAll().forEach(System.out::println);
        System.out.println("*********************");
        fText.getSortedLines().forEach(System.out::println);
    }
}
